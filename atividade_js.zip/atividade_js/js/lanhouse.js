
const inputValor = document.querySelector("#inputValor")
const inputTempo = document.querySelector("#inputTempo")

const btnCalculo = document.querySelector("#btnCalculo")

btnCalculo.addEventListener("click", ()=>{
    let calculo = 0
    let vezes = 0

    if ((inputTempo.value != "") && (inputValor.value != "")){

        vezes = parseInt((inputTempo.value)/15)

        if ( parseInt(inputTempo.value)%15 != 0 ){ //se o resto for igual a 0
            vezes += 1 //Adiciona uma vez a mais
        } 

        calculo = parseFloat((inputValor.value)*vezes)

    } else{
        vezes, calculo = 0
    }


    document.getElementById("divResposta").innerHTML = "Valor a Pagar: R$ " + calculo.toFixed(2)

})