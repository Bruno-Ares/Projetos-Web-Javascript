const inputMed = document.querySelector("#inputMed")
const inputPreco = document.querySelector("#inputPreco")
const btnDesconto = document.querySelector("#btnDesconto")


btnDesconto.addEventListener("click", ()=>{
    let medicamento, val

    if (inputMed.value == ""){
        medicamento = "Nada"
    } else{
        medicamento = inputMed.value
    }

    if (inputPreco.value == ""){
        val = 0
    } else{
        val = (parseInt(inputPreco.value)) * 2
    }

    document.getElementById("divRespTitulo").innerHTML = "Promoção de " + medicamento
    document.getElementById("divRespPromo").innerHTML = "Leve 2 por apenas R$ " + val.toFixed(2)

})