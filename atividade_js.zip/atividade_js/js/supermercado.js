const inputProduto = document.querySelector("#inputProduto")
const inputPreco = document.querySelector("#inputPreco")
const btnPromocao = document.querySelector("#btnPromocao")

btnPromocao.addEventListener("click", ()=>{
    let valor = 0
    let produto = 0
    let desconto = 0

    if (inputProduto.value == ""){
        produto = "Nada"
    } else{
        produto = inputProduto.value
    }

    if (inputPreco.value == ""){
        valor = 0
        desconto = 0
    } else{
        desconto = parseFloat(inputPreco.value)*0.5
        valor = parseFloat((parseFloat(inputPreco.value)*2) + desconto)
    }

    document.getElementById("divRespPromocao").innerHTML = produto + " - Promoção: Leve 3 por R$ " + valor.toFixed(2)
    document.getElementById("divRespValor").innerHTML = "O 3° produto custa apenas R$ " + desconto.toFixed(2)
})